public class Funcionario {
}
