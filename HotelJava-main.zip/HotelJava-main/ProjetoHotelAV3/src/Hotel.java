public class Hotel {

    String nome;


}
