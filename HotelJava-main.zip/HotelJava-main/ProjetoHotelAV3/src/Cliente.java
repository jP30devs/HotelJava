import java.util.List;

public class Cliente {

    public String nome_cliente;

    public int cpf_cliente;

    public List<Reserva> reservas;
}
